function flattenStruct(s)
% flattenStruct(s)	Puts each field of s into the current workspace.

error('You need to compile flattenStruct.c!');
