import os
deltasigma_theme_path = os.path.split(os.path.split(__file__)[0])[0]
